from models.order import OrderStatus
from utils.helpers import cetak_header

class OrderService:
    """
    Service untuk mengelola data order:
    - melihat daftar order
    - melihat detail order
    - update status order
    """

    def __init__(self, marketplace):
        self.__market = marketplace

    def tampilkan_semua_order(self):
        """Menampilkan seluruh order yang tersimpan di sistem."""
        cetak_header("DAFTAR ORDER MASUK")

        daftar = self.__market.get_semua_order()

        if len(daftar) == 0:
            print("  Belum terdapat order.\n")
            return

        for idx, item_order in enumerate(daftar, start=1):
            print(f"  {idx}. {item_order}")

        print()

    def tampilkan_detail_order(self):
        """Menampilkan detail satu order berdasarkan ID."""
        target_id = input("  Input Order ID : ").strip()

        data_order = self.__market.cari_order(target_id)

        if not data_order:
            print(f"[Order] Data dengan ID '{target_id}' tidak ditemukan.\n")
            return

        print(data_order.get_detail())

    def update_status_order(self):
        """
        Update status order (hanya bisa maju):
        Pending → Diproses → Selesai
        """
        cetak_header("UBAH STATUS ORDER")

        self.tampilkan_semua_order()

        target_id = input("  Order ID yang akan diubah : ").strip()

        data_order = self.__market.cari_order(target_id)

        if data_order is None:
            print(f"[Order] Order '{target_id}' tidak ditemukan.\n")
            return

        print(f"\n  Status saat ini : {data_order.status.value}")
        print("  Pilih status baru:")
        print("  1. Diproses")
        print("  2. Selesai")

        opsi = input("  Pilihan : ").strip()

        if opsi == "1":
            new_status = OrderStatus.PROCESSING
        elif opsi == "2":
            new_status = OrderStatus.COMPLETED
        else:
            print("[Order] Input tidak valid.\n")
            return

        if data_order.update_status(new_status):
            print(
                f"[Order] Status order {target_id} "
                f"berhasil diubah menjadi '{new_status.value}'.\n"
            )