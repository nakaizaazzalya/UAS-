from models.admin import Admin
from models.product import Product
from utils.helpers import generate_id


class Marketplace:
    """
    Kelas pusat sistem yang mengelola:
    - Data produk
    - Data order
    - Data user
    """

    def __init__(self, nama_toko="Toko Online PBO"):
        self.__store_name = nama_toko
        self.__products = []
        self.__orders = []
        self.__users = []

        # inisialisasi data awal
        self._create_default_admin()
        self._create_sample_products()

    @property
    def nama_toko(self):
        return self.__store_name

    # ===== DATA AWAL =====
    def _create_default_admin(self):
        admin = Admin("admin", "admin123")
        self.__users.append(admin)

    def _create_sample_products(self):
        sample_data = [
            Product(generate_id("PRD"), "Laptop Asus VivoBook", 7_500_000, 10,
                    "Intel i5, RAM 8GB, SSD 512GB"),
            Product(generate_id("PRD"), "Mouse Wireless Logitech", 150_000, 50,
                    "DPI 1600, baterai tahan lama"),
            Product(generate_id("PRD"), "Keyboard Mechanical", 350_000, 25,
                    "Switch Blue, RGB backlight"),
            Product(generate_id("PRD"), "Headset Gaming Rexus", 200_000, 30,
                    "Surround 7.1, mic noise cancel"),
        ]

        self.__products.extend(sample_data)

    # ===== PRODUCT MANAGEMENT =====
    def tambah_produk(self, produk):
        self.__products.append(produk)

    def hapus_produk(self, product_id):
        target = None

        for item in self.__products:
            if item.product_id == product_id:
                target = item
                break

        if target:
            self.__products.remove(target)
            return True

        return False

    def cari_produk(self, product_id):
        for item in self.__products:
            if item.product_id == product_id:
                return item
        return None

    def cari_produk_by_nama(self, keyword):
        keyword_lower = keyword.lower()

        return [
            item
            for item in self.__products
            if keyword_lower in item.nama.lower()
        ]

    def get_produk(self):
        return self.__products.copy()

    # ===== ORDER MANAGEMENT =====
    def tambah_order(self, order):
        self.__orders.append(order)

    def cari_order(self, order_id):
        for order in self.__orders:
            if order.order_id == order_id:
                return order
        return None

    def get_semua_order(self):
        return self.__orders.copy()

    # ===== USER MANAGEMENT =====
    def daftarkan_user(self, user):
        self.__users.append(user)

    def cari_user(self, username):
        for user in self.__users:
            if user.username == username:
                return user
        return None

    def username_tersedia(self, username):
        return self.cari_user(username) is None

    def get_semua_user(self):
        return self.__users.copy()

    def __str__(self):
        return (
            f"=== {self.__store_name} ===\n"
            f"Produk : {len(self.__products)}\n"
            f"Order  : {len(self.__orders)}\n"
            f"User   : {len(self.__users)}"
        )