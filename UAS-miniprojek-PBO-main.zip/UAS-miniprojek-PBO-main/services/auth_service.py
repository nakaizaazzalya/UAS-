from models.customer import Customer
from utils.helpers import cetak_header


class AuthService:
    """
    Mengelola proses autentikasi pengguna,
    seperti login, logout, dan registrasi akun customer.
    """

    def __init__(self, marketplace):
        self.__marketplace = marketplace
        self.__current_user = None

    @property
    def user_aktif(self):
        return self.__current_user

    def sudah_login(self):
        return (
            self.__current_user is not None
            and self.__current_user.is_logged_in
        )

    def login(self):
        """Login untuk akun admin maupun customer."""

        cetak_header("LOGIN AKUN")

        username = input("  Username : ").strip()
        password = input("  Password : ").strip()

        akun = self.__marketplace.cari_user(username)

        if akun is None:
            print("\n[Auth] Akun tidak ditemukan.\n")
            return False

        if akun.login(password):
            self.__current_user = akun
            print()
            return True

        print()
        return False

    def logout(self):
        """Mengakhiri sesi pengguna yang sedang aktif."""

        if self.__current_user:
            self.__current_user.logout()
            self.__current_user = None

    def register_customer(self):
        """
        Registrasi customer baru.
        Akun admin hanya dapat dibuat secara manual.
        """

        cetak_header("REGISTRASI CUSTOMER")
        print("  Silakan lengkapi data berikut:\n")

        username = input("  Username      : ").strip()

        if username == "":
            print("[Register] Username wajib diisi.\n")
            return False

        if not self.__marketplace.username_tersedia(username):
            print("[Register] Username sudah digunakan.\n")
            return False

        password = input("  Password      : ").strip()

        if len(password) < 4:
            print("[Register] Password minimal 4 karakter.\n")
            return False

        nama = input("  Nama Lengkap  : ").strip()
        alamat = input("  Alamat        : ").strip()
        telepon = input("  No. Telepon   : ").strip()

        if any(data == "" for data in [nama, alamat, telepon]):
            print("[Register] Semua data harus diisi.\n")
            return False

        akun_baru = Customer(
            username,
            password,
            nama,
            alamat,
            telepon
        )

        self.__marketplace.daftarkan_user(akun_baru)

        print(
            f"\n[Register] Akun '{username}' berhasil dibuat."
            f" Silakan login.\n"
        )

        return True