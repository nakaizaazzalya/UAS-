from models.order import OrderStatus


class TransactionHistory:
    def __init__(self):
        self.__daftar_order = []

    def tambah_order(self, order):
        self.__daftar_order.append(order)

    def get_semua(self):
        return self.__daftar_order.copy()

    def get_by_status(self, status):
        return [
            order
            for order in self.__daftar_order
            if order.status == status
        ]

    def sudah_beli(self, produk):
        # Memastikan produk pernah dibeli dan order telah selesai
        for transaksi in self.__daftar_order:
            if (
                transaksi.status == OrderStatus.COMPLETED
                and transaksi.berisi_produk(produk)
            ):
                return True

        return False

    def tampilkan(self):
        if len(self.__daftar_order) == 0:
            print("[Riwayat] Tidak ada transaksi yang tersimpan.")
            return

        print("\n===== DAFTAR RIWAYAT TRANSAKSI =====")

        for nomor, transaksi in enumerate(
                self.__daftar_order, start=1):
            print(f"  {nomor}. {transaksi}")

        print("====================================\n")

    def tampilkan_detail(self, order_id):
        for transaksi in self.__daftar_order:
            if transaksi.order_id == order_id:
                print(transaksi.get_detail())
                return

        print(
            f"[Riwayat] Data order dengan ID "
            f"'{order_id}' tidak ditemukan."
        )