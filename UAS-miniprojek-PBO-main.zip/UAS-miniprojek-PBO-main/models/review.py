from datetime import datetime


class Review:
    def __init__(self, customer, rating, komentar):
        # Validasi nilai rating
        if rating < 1 or rating > 5:
            raise ValueError("Nilai rating harus berada pada rentang 1 - 5.")

        self.__pengguna = customer
        self.__nilai_rating = rating
        self.__isi_komentar = komentar
        self.__waktu_review = datetime.now()

    @property
    def customer(self):
        return self.__pengguna

    @property
    def rating(self):
        return self.__nilai_rating

    @property
    def komentar(self):
        return self.__isi_komentar

    @property
    def tanggal(self):
        return self.__waktu_review

    def get_rating(self):
        return self.__nilai_rating

    def __str__(self):
        simbol_bintang = (
            "★" * self.__nilai_rating +
            "☆" * (5 - self.__nilai_rating)
        )

        tanggal_review = self.__waktu_review.strftime("%d-%m-%Y")

        return (
            f"  {simbol_bintang} ({self.__nilai_rating}/5)\n"
            f"  Oleh      : {self.__pengguna.username}\n"
            f"  Tanggal   : {tanggal_review}\n"
            f"  Komentar  : {self.__isi_komentar}"
        )