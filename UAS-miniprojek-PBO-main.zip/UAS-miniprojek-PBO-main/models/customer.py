from models.user import User
from models.cart import Cart
from models.transaction_history import TransactionHistory

class Customer(User):
    def __init__(self, username, password, nama_lengkap, alamat, no_telepon):
        super().__init__(username, password)

        self.__nama = nama_lengkap
        self.__alamat_rumah = alamat
        self.__telepon = no_telepon

        # Composition
        self.__keranjang = Cart()
        self.__riwayat_transaksi = TransactionHistory()

    # Getter
    @property
    def nama_lengkap(self):
        return self.__nama

    @property
    def alamat(self):
        return self.__alamat_rumah

    @property
    def no_telepon(self):
        return self.__telepon

    @property
    def cart(self):
        return self.__keranjang

    @property
    def history(self):
        return self.__riwayat_transaksi

    # Override login
    def login(self, password):
        if self.check_password(password):
            self._is_logged_in = True
            print(f"[Customer] Halo, {self.__nama}. Login berhasil.")
            return True

        print("[Customer] Gagal login. Username atau password salah.")
        return False

    def logout(self):
        self._is_logged_in = False
        print(f"[Customer] {self.__nama} berhasil logout.")

    # Override method get_info
    def get_info(self):
        status_akun = "Login" if self._is_logged_in else "Logout"

        return (
            f"=== DATA CUSTOMER ===\n"
            f"Username     : {self._username}\n"
            f"Nama Lengkap : {self.__nama}\n"
            f"Alamat       : {self.__alamat_rumah}\n"
            f"No. Telepon  : {self.__telepon}\n"
            f"Status       : {status_akun}"
        )

    def tambah_ke_cart(self, produk, qty):
        self.__keranjang.tambah_item(produk, qty)

    def hapus_dari_cart(self, produk):
        self.__keranjang.hapus_item(produk)

    def lihat_cart(self):
        self.__keranjang.tampilkan()

    def checkout(self, marketplace):
        if self.__keranjang.kosong():
            print("[Customer] Keranjang masih kosong.")
            return None

        from models.order import Order
        from utils.helpers import generate_id

        id_order = generate_id("ORD")

        item_pesanan = dict(self.__keranjang.get_items())
        total_bayar = self.__keranjang.get_total()

        # Validasi stok terlebih dahulu
        for produk, jumlah in item_pesanan.items():
            if produk.stok < jumlah:
                print(
                    f"[Customer] Stok '{produk.nama}' tidak mencukupi. "
                    f"Tersedia: {produk.stok}, diminta: {jumlah}."
                )
                return None

        # Kurangi stok produk
        for produk, jumlah in item_pesanan.items():
            produk.kurangi_stok(jumlah)

        pesanan = Order(
            id_order,
            self,
            item_pesanan,
            total_bayar
        )

        self.__riwayat_transaksi.tambah_order(pesanan)
        marketplace.tambah_order(pesanan)

        self.__keranjang.kosongkan()

        print(f"[Customer] Checkout sukses. ID Order: {id_order}")
        print(f"           Total Pembayaran: Rp {total_bayar:,.0f}")

        return pesanan

    def beri_ulasan(self, produk, rating, komentar):
        from models.review import Review

        # Pastikan customer pernah membeli produk
        if not self.__riwayat_transaksi.sudah_beli(produk):
            print("[Customer] Produk belum pernah dibeli.")
            return None

        # Cek apakah sudah memberi review
        if produk.sudah_direview_oleh(self):
            print("[Customer] Review untuk produk ini sudah pernah diberikan.")
            return None

        ulasan = Review(self, rating, komentar)

        produk.tambah_review(ulasan)

        print(
            f"[Customer] Ulasan untuk produk "
            f"'{produk.nama}' berhasil ditambahkan."
        )

        return ulasan

    def lihat_riwayat(self):
        self.__riwayat_transaksi.tampilkan()

    def __str__(self):
        return (
            f"Customer("
            f"{self._username} | "
            f"{self.__nama}"
            f")"
        )