from enum import Enum
from datetime import datetime


class OrderStatus(Enum):
    PENDING = "Pending"
    PROCESSING = "Diproses"
    COMPLETED = "Selesai"


class Order:
    def __init__(self, order_id, customer, items, total):
        self.__id_order = order_id
        self.__pelanggan = customer
        self.__daftar_item = items      # snapshot item saat checkout
        self.__total_bayar = total
        self.__status_order = OrderStatus.PENDING
        self.__waktu_pesan = datetime.now()

    # Getter
    @property
    def order_id(self):
        return self.__id_order

    @property
    def customer(self):
        return self.__pelanggan

    @property
    def items(self):
        return self.__daftar_item

    @property
    def total(self):
        return self.__total_bayar

    @property
    def status(self):
        return self.__status_order

    @property
    def tanggal(self):
        return self.__waktu_pesan

    def update_status(self, status_baru):
        if not isinstance(status_baru, OrderStatus):
            print("[Order] Status yang diberikan tidak valid.")
            return False

        daftar_status = [
            OrderStatus.PENDING,
            OrderStatus.PROCESSING,
            OrderStatus.COMPLETED
        ]

        posisi_lama = daftar_status.index(self.__status_order)
        posisi_baru = daftar_status.index(status_baru)

        # Tidak boleh kembali ke status sebelumnya
        if posisi_baru <= posisi_lama:
            print(
                f"[Order] Status tidak dapat diubah dari "
                f"'{self.__status_order.value}' "
                f"menjadi '{status_baru.value}'."
            )
            return False

        self.__status_order = status_baru
        return True

    def get_detail(self):
        tanggal_order = self.__waktu_pesan.strftime("%d-%m-%Y %H:%M")

        detail_item = ""

        for produk, jumlah in self.__daftar_item.items():
            subtotal = produk.harga * jumlah

            detail_item += (
                f"  - {produk.nama:<25} "
                f"x{jumlah} "
                f"Rp {subtotal:>12,.0f}\n"
            )

        return (
            f"\n===== INFORMASI ORDER =====\n"
            f"ID Order  : {self.__id_order}\n"
            f"Tanggal   : {tanggal_order}\n"
            f"Customer  : {self.__pelanggan.nama_lengkap}\n"
            f"Status    : {self.__status_order.value}\n"
            f"Daftar Item:\n"
            f"{detail_item}"
            f"{'-' * 45}\n"
            f"Total     : Rp {self.__total_bayar:>12,.0f}\n"
            f"===========================\n"
        )

    def berisi_produk(self, produk):
        return produk in self.__daftar_item

    def __str__(self):
        tanggal_order = self.__waktu_pesan.strftime("%d-%m-%Y %H:%M")

        return (
            f"Order #{self.__id_order} | "
            f"{tanggal_order} | "
            f"Rp {self.__total_bayar:,.0f} | "
            f"Status: {self.__status_order.value}"
        )