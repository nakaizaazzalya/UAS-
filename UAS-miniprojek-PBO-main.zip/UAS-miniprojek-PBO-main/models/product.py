class Product:
    def __init__(self, product_id, nama, harga, stok, deskripsi=""):
        self.__id_produk = product_id
        self.__nama_produk = nama
        self.__harga_produk = harga
        self.__jumlah_stok = stok
        self.__keterangan = deskripsi
        self.__daftar_review = []

    # Property untuk mengakses atribut private
    @property
    def product_id(self):
        return self.__id_produk

    @property
    def nama(self):
        return self.__nama_produk

    @property
    def harga(self):
        return self.__harga_produk

    @property
    def stok(self):
        return self.__jumlah_stok

    @property
    def deskripsi(self):
        return self.__keterangan

    @property
    def reviews(self):
        # Mengembalikan salinan list agar data asli tetap aman
        return self.__daftar_review.copy()

    def kurangi_stok(self, qty):
        if qty > self.__jumlah_stok:
            raise ValueError(
                f"Stok tidak mencukupi. Sisa stok: {self.__jumlah_stok}"
            )

        self.__jumlah_stok -= qty

    def tambah_stok(self, qty):
        self.__jumlah_stok += qty

    def tambah_review(self, review):
        self.__daftar_review.append(review)

    def sudah_direview_oleh(self, customer):
        return any(
            review.customer.username == customer.username
            for review in self.__daftar_review
        )

    def get_avg_rating(self):
        if len(self.__daftar_review) == 0:
            return 0.0

        total_rating = sum(
            review.rating
            for review in self.__daftar_review
        )

        return round(
            total_rating / len(self.__daftar_review),
            1
        )

    def __str__(self):
        rata_rating = self.get_avg_rating()

        info_rating = (
            f"{rata_rating}/5.0"
            if rata_rating > 0
            else "Belum ada rating"
        )

        return (
            f"[{self.__id_produk}] {self.__nama_produk}\n"
            f"  Harga      : Rp {self.__harga_produk:,.0f}\n"
            f"  Stok       : {self.__jumlah_stok} pcs\n"
            f"  Rating     : {info_rating}\n"
            f"  Deskripsi  : {self.__keterangan if self.__keterangan else '-'}"
        )