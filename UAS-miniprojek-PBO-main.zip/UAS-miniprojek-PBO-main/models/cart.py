class Cart:
    def __init__(self):
        # Menyimpan pasangan Product dan jumlahnya
        self.__keranjang = {}

    def tambah_item(self, produk, qty=1):
        if qty <= 0:
            print("[Cart] Jumlah pembelian harus lebih dari 0.")
            return

        if qty > produk.stok:
            print(
                f"[Cart] Stok produk '{produk.nama}' tidak mencukupi. "
                f"Sisa stok: {produk.stok}."
            )
            return

        self.__keranjang[produk] = self.__keranjang.get(produk, 0) + qty

        print(f"[Cart] Produk '{produk.nama}' sebanyak {qty} berhasil ditambahkan.")

    def hapus_item(self, produk):
        if produk not in self.__keranjang:
            print(f"[Cart] Produk '{produk.nama}' tidak ditemukan di cart.")
            return

        self.__keranjang.pop(produk)
        print(f"[Cart] Produk '{produk.nama}' berhasil dihapus.")

    def get_total(self):
        total_harga = 0

        for barang, jumlah in self.__keranjang.items():
            total_harga += barang.harga * jumlah

        return total_harga

    def get_items(self):
        return self.__keranjang

    def kosong(self):
        return len(self.__keranjang) == 0

    def kosongkan(self):
        self.__keranjang.clear()

    def tampilkan(self):
        if self.kosong():
            print("[Cart] Keranjang belanja masih kosong.")
            return

        print("\n===== DAFTAR BELANJA =====")

        for no, (barang, jumlah) in enumerate(
                self.__keranjang.items(), start=1):

            subtotal = barang.harga * jumlah

            print(
                f"{no}. {barang.nama:<25} "
                f"x{jumlah}  "
                f"@ Rp {barang.harga:>10,.0f}  "
                f"= Rp {subtotal:>12,.0f}"
            )

        print("-" * 48)
        print(f"Total Belanja : Rp {self.get_total():>12,.0f}")
        print("==========================\n")