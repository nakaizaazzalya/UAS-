from abc import ABC, abstractmethod


class User(ABC):
    def __init__(self, username, password):
        self._username = username
        self.__user_password = password
        self._is_logged_in = False

    # Property untuk mengakses data username dan status login
    @property
    def username(self):
        return self._username

    @property
    def is_logged_in(self):
        return self._is_logged_in

    def check_password(self, password):
        return password == self.__user_password

    # Method abstrak yang harus diimplementasikan subclass
    @abstractmethod
    def login(self, password):
        raise NotImplementedError

    @abstractmethod
    def logout(self):
        raise NotImplementedError

    @abstractmethod
    def get_info(self):
        raise NotImplementedError

    def __str__(self):
        return f"User Account ({self._username})"