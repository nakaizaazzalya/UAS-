from models.user import User


class Admin(User):
    def __init__(self, username, password):
        super().__init__(username, password)

        # Menyimpan referensi produk dan order yang dikelola admin
        self.__produk_dikelola = []
        self.__order_dikelola = []

    # Override method login
    def login(self, password):
        if self.check_password(password):
            self._is_logged_in = True
            print(f"[ADMIN] Halo, {self._username}! Login berhasil.")
            return True

        print("[ADMIN] Password yang dimasukkan tidak valid.")
        return False

    def logout(self):
        self._is_logged_in = False
        print(f"[ADMIN] User {self._username} berhasil logout.")

    # Override method get_info
    def get_info(self):
        status_login = "Login" if self._is_logged_in else "Logout"

        return (
            f"=== DATA ADMIN ===\n"
            f"Username : {self._username}\n"
            f"Role     : Administrator\n"
            f"Status   : {status_login}"
        )

    def tambah_produk(self, marketplace, nama, harga, stok, deskripsi=""):
        from models.product import Product
        from utils.helpers import generate_id

        produk = Product(
            generate_id("PRD"),
            nama,
            harga,
            stok,
            deskripsi
        )

        marketplace.tambah_produk(produk)
        self.__produk_dikelola.append(produk)

        print(f"[ADMIN] Produk '{nama}' sukses ditambahkan.")
        return produk

    def hapus_produk(self, marketplace, product_id):
        berhasil = marketplace.hapus_produk(product_id)

        if berhasil:
            print(f"[ADMIN] Produk dengan ID {product_id} berhasil dihapus.")
        else:
            print(f"[ADMIN] Produk dengan ID {product_id} tidak ditemukan.")

        return berhasil

    def update_status_order(self, marketplace, order_id, status_baru):
        data_order = marketplace.cari_order(order_id)

        if data_order is None:
            print(f"[ADMIN] Order dengan ID {order_id} tidak ditemukan.")
            return False

        data_order.update_status(status_baru)

        print(
            f"[ADMIN] Status order {order_id} berhasil diperbarui "
            f"menjadi '{status_baru.value}'."
        )
        return True

    def lihat_semua_order(self, marketplace):
        daftar_order = marketplace.get_semua_order()

        if len(daftar_order) == 0:
            print("[ADMIN] Belum terdapat order.")
            return

        print("\n=== DAFTAR ORDER ===")
        for item in daftar_order:
            print(item)

    def lihat_semua_produk(self, marketplace):
        daftar_produk = marketplace.get_produk()

        if not daftar_produk:
            print("[ADMIN] Tidak ada produk yang tersedia.")
            return

        print("\n=== DAFTAR PRODUK ===")
        for produk in daftar_produk:
            print(produk)

    def __str__(self):
        return f"Admin User ({self._username})"