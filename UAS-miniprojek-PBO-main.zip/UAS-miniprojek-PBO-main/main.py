from services.marketplace import Marketplace
from services.auth_service import AuthService
from services.order_service import OrderService
from models.admin import Admin
from models.customer import Customer
from models.order import OrderStatus
from utils.helpers import cetak_header, cetak_garis

# ===== INISIALISASI =====
marketplace = Marketplace("Marketplace - NAZIRWAME")
auth_service = AuthService(marketplace)
order_service = OrderService(marketplace)

# ===== ADMIN MENU =====
def admin_menu(admin):
    while True:
        cetak_header(f"ADMIN MENU [{admin.username}]")

        print("  1. Lihat Produk")
        print("  2. Tambah Produk")
        print("  3. Hapus Produk")
        print("  4. Semua Order")
        print("  5. Update Status Order")
        print("  6. Detail Order")
        print("  7. Profil Admin")
        print("  0. Logout")

        cetak_garis()
        choice = input("  Pilihan : ").strip()

        if choice == "1":
            admin.lihat_semua_produk(marketplace)

        elif choice == "2":
            cetak_header("TAMBAH PRODUK")

            nama = input("  Nama   : ").strip()

            try:
                harga = float(input("  Harga  : ").strip())
                stok = int(input("  Stok   : ").strip())
            except ValueError:
                print("[Error] Harga/Stok harus angka.\n")
                continue

            desc = input("  Deskripsi : ").strip()
            admin.tambah_produk(marketplace, nama, harga, stok, desc)

        elif choice == "3":
            admin.lihat_semua_produk(marketplace)
            pid = input("  ID Produk : ").strip()
            admin.hapus_produk(marketplace, pid)

        elif choice == "4":
            order_service.tampilkan_semua_order()

        elif choice == "5":
            order_service.update_status_order()

        elif choice == "6":
            order_service.tampilkan_detail_order()

        elif choice == "7":
            print("\n" + admin.get_info() + "\n")

        elif choice == "0":
            auth_service.logout()
            break

        else:
            print("[Menu] Input tidak valid.\n")

# ===== CUSTOMER MENU =====
def customer_menu(customer):
    while True:
        cetak_header(f"CUSTOMER MENU [{customer.nama_lengkap}]")

        print("  1. Semua Produk")
        print("  2. Cari Produk")
        print("  3. Tambah ke Cart")
        print("  4. Lihat Cart")
        print("  5. Hapus Item Cart")
        print("  6. Checkout")
        print("  7. Riwayat")
        print("  8. Review Produk")
        print("  9. Profil")
        print("  0. Logout")

        cetak_garis()
        choice = input("  Pilihan : ").strip()

        if choice == "1":
            show_products()

        elif choice == "2":
            keyword = input("  Cari : ").strip()
            result = marketplace.cari_produk_by_nama(keyword)

            if not result:
                print("[Produk] Tidak ditemukan.\n")
            else:
                print(f"\nDitemukan {len(result)} produk:\n")
                for p in result:
                    print(p)
                    cetak_garis("-")

        elif choice == "3":
            show_products()

            pid = input("  ID Produk : ").strip()
            product = marketplace.cari_produk(pid)

            if not product:
                print("[Produk] Tidak ditemukan.\n")
                continue

            try:
                qty = int(input("  Qty : ").strip())
            except ValueError:
                print("[Error] Qty harus angka.\n")
                continue

            customer.tambah_ke_cart(product, qty)

        elif choice == "4":
            customer.lihat_cart()

        elif choice == "5":
            customer.lihat_cart()
            pid = input("  ID Produk : ").strip()

            product = marketplace.cari_produk(pid)
            if product:
                customer.hapus_dari_cart(product)

        elif choice == "6":
            customer.lihat_cart()

            if input("Checkout? (y/n): ").lower() == "y":
                customer.checkout(marketplace)

        elif choice == "7":
            customer.lihat_riwayat()

        elif choice == "8":
            review_menu(customer)

        elif choice == "9":
            print("\n" + customer.get_info() + "\n")

        elif choice == "0":
            auth_service.logout()
            break

        else:
            print("[Menu] Tidak valid.\n")

# ===== REVIEW MENU =====
def review_menu(customer):
    cetak_header("REVIEW PRODUK")

    orders = customer.history.get_by_status(OrderStatus.COMPLETED)
    products = []

    for o in orders:
        for p in o.items:
            if p not in products:
                products.append(p)

    if not products:
        print("  Belum ada produk yang bisa direview.\n")
        return

    for i, p in enumerate(products, 1):
        print(f"  {i}. [{p.product_id}] {p.nama}")

    pid = input("  Pilih ID : ").strip()
    product = marketplace.cari_produk(pid)

    if not product:
        print("[Review] Produk tidak ditemukan.\n")
        return

    try:
        rating = int(input("  Rating (1-5): ").strip())
    except ValueError:
        print("[Error] Rating harus angka.\n")
        return

    comment = input("  Komentar : ").strip()
    customer.beri_ulasan(product, rating, comment)

# ===== PRODUCT VIEW =====
def show_products():
    products = marketplace.get_produk()

    if not products:
        print("\n[Info] Tidak ada produk.\n")
        return

    print(f"\n=== PRODUK ({len(products)}) ===\n")
    for p in products:
        print(p)
        cetak_garis("-")

# ===== MAIN MENU ======
def main_menu():
    while True:
        cetak_header(marketplace.nama_toko)

        print("  1. Login")
        print("  2. Register")
        print("  3. Lihat Produk")
        print("  0. Exit")

        cetak_garis()
        choice = input("  Pilihan : ").strip()

        if choice == "1":
            if auth_service.login():
                user = auth_service.user_aktif

                if isinstance(user, Admin):
                    admin_menu(user)
                else:
                    customer_menu(user)

        elif choice == "2":
            auth_service.register_customer()

        elif choice == "3":
            show_products()

        elif choice == "0":
            print("\nBye!\n")
            break

        else:
            print("[Menu] Tidak valid.\n")

# ===== RUN APP =====
if __name__ == "__main__":
    print("\n=== MARKETPLACE SYSTEM STARTED ===\n")
    main_menu()