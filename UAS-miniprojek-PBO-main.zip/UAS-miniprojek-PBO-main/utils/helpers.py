import uuid

def generate_id(prefix="ID"):
    """
    Membuat ID unik dengan format PREFIX-XXXXXXXX
    Contoh: PRD-A1B2C3D4 / ORD-9F3E1A2B
    """
    random_code = uuid.uuid4().hex[:8].upper()
    return f"{prefix}-{random_code}"

def format_rupiah(value):
    """
    Mengubah angka menjadi format mata uang Rupiah.
    Contoh: 75000 -> Rp 75.000
    """
    return "Rp {:,.0f}".format(value).replace(",", ".")

def cetak_garis(symbol="=", length=45):
    """Menampilkan garis pemisah di terminal."""
    print(symbol * length)

def cetak_header(title):
    """Menampilkan judul header dengan pembatas garis."""

    cetak_garis()
    print(f"  {title.upper()}")
    cetak_garis()